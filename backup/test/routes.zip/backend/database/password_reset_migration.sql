-- Password Reset Requests Table for Intern Dashboard
-- Run this migration to add password reset functionality
-- Admin will approve requests, then interns can reset their password

CREATE TABLE IF NOT EXISTS password_reset_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    intern_id INT NOT NULL,
    email VARCHAR(100) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'used') DEFAULT 'pending',
    admin_notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    approved_at DATETIME NULL,
    used_at DATETIME NULL,
    FOREIGN KEY (intern_id) REFERENCES interns(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_email (email),
    INDEX idx_intern (intern_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Drop old token-based table if exists (we're switching to admin-approval flow)
-- DROP TABLE IF EXISTS password_reset_tokens;
