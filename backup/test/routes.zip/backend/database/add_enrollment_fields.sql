-- Migration: Add additional fields to track application form data

-- Add queries field to internship_enrollments
ALTER TABLE internship_enrollments 
ADD COLUMN IF NOT EXISTS queries TEXT NULL COMMENT 'Student queries from application form' AFTER amount_paid;

-- Add additional fields to interns table if they don't exist
ALTER TABLE interns 
ADD COLUMN IF NOT EXISTS gender VARCHAR(20) NULL AFTER full_name,
ADD COLUMN IF NOT EXISTS college_name VARCHAR(255) NULL AFTER phone,
ADD COLUMN IF NOT EXISTS academic_degree VARCHAR(100) NULL AFTER college_name,
ADD COLUMN IF NOT EXISTS current_year VARCHAR(20) NULL AFTER academic_degree,
ADD COLUMN IF NOT EXISTS country VARCHAR(100) DEFAULT 'INDIA' AFTER current_year,
ADD COLUMN IF NOT EXISTS source VARCHAR(100) NULL AFTER country;

-- Add notes field for admin to add comments
ALTER TABLE internship_enrollments 
ADD COLUMN IF NOT EXISTS admin_notes TEXT NULL COMMENT 'Admin notes about the application' AFTER queries;

-- Add reviewed status
ALTER TABLE internship_enrollments 
ADD COLUMN IF NOT EXISTS reviewed_by INT NULL COMMENT 'Admin user who reviewed' AFTER admin_notes,
ADD COLUMN IF NOT EXISTS reviewed_at DATETIME NULL COMMENT 'When application was reviewed' AFTER reviewed_by;

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_enrollment_status ON internship_enrollments(enrollment_status, payment_status);
CREATE INDEX IF NOT EXISTS idx_enrollment_date ON internship_enrollments(enrollment_date DESC);
