-- Migration: Add video progress tracking fields
-- This adds the ability to track exact video position for resume functionality

ALTER TABLE intern_video_progress 
ADD COLUMN IF NOT EXISTS seconds_watched INT DEFAULT 0 COMMENT 'Maximum seconds watched in the video',
ADD COLUMN IF NOT EXISTS total_seconds INT DEFAULT 0 COMMENT 'Total video duration in seconds',
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last progress update time';

-- Update existing records to have default values
UPDATE intern_video_progress 
SET seconds_watched = 0, total_seconds = 0 
WHERE seconds_watched IS NULL OR total_seconds IS NULL;
