-- Course Students Schema
-- This table stores walk-in course student registrations (separate from internship enrollments)

-- Ensure the correct database is selected
USE itinfo_academy;

CREATE TABLE IF NOT EXISTS course_students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    gender VARCHAR(20) NOT NULL,
    college_name VARCHAR(150) NOT NULL,
    academic_degree VARCHAR(100) NOT NULL,
    current_year VARCHAR(10) NOT NULL,
    course_id INT NOT NULL,
    other_course_name VARCHAR(150) NULL,
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    amount_paid DECIMAL(10, 2) NOT NULL,
    roll_no VARCHAR(50) NULL UNIQUE,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_roll_no (roll_no),
    INDEX idx_course_id (course_id),
    INDEX idx_active (is_active),
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
