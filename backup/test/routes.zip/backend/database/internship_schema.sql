-- Internship System Database Schema

-- Internships Table
CREATE TABLE IF NOT EXISTS internships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT NOT NULL,
    duration VARCHAR(50) NOT NULL,
    fees DECIMAL(10,2) NOT NULL,
    image_url VARCHAR(255) NULL,
    is_active TINYINT(1) DEFAULT 1,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_slug (slug),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Interns Table (Users for the internship system)
CREATE TABLE IF NOT EXISTS interns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NULL,
    profile_image VARCHAR(255) NULL,
    is_active TINYINT(1) DEFAULT 1,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Internship Enrollments Table
CREATE TABLE IF NOT EXISTS internship_enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    intern_id INT NOT NULL,
    internship_id INT NOT NULL,
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_method ENUM('online', 'cash') NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    enrollment_status ENUM('pending', 'active', 'completed', 'cancelled') DEFAULT 'pending',
    transaction_id VARCHAR(100) NULL,
    amount_paid DECIMAL(10,2) NOT NULL,
    certificate_issued TINYINT(1) DEFAULT 0,
    certificate_date DATETIME NULL,
    FOREIGN KEY (intern_id) REFERENCES interns(id) ON DELETE CASCADE,
    FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE,
    INDEX idx_intern (intern_id),
    INDEX idx_internship (internship_id),
    INDEX idx_status (enrollment_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Internship Videos Table
CREATE TABLE IF NOT EXISTS internship_videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    internship_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    video_url VARCHAR(255) NOT NULL,
    duration VARCHAR(20) NULL,
    display_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE,
    INDEX idx_internship (internship_id),
    INDEX idx_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Internship Questionnaires (Quizzes) Table
CREATE TABLE IF NOT EXISTS internship_quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    video_id INT NOT NULL,
    passing_score INT DEFAULT 70, -- Percentage
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (video_id) REFERENCES internship_videos(id) ON DELETE CASCADE,
    UNIQUE (video_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Internship Questions Table
CREATE TABLE IF NOT EXISTS internship_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('mcq', 'tf', 'short_answer') DEFAULT 'mcq',
    correct_answer TEXT NULL, -- For short answer or storing correct option ID/value
    points INT DEFAULT 1,
    FOREIGN KEY (quiz_id) REFERENCES internship_quizzes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Internship MCQ Options Table
CREATE TABLE IF NOT EXISTS internship_question_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT NOT NULL,
    option_text TEXT NOT NULL,
    is_correct TINYINT(1) DEFAULT 0,
    FOREIGN KEY (question_id) REFERENCES internship_questions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Intern Video Progress Table
CREATE TABLE IF NOT EXISTS intern_video_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    intern_id INT NOT NULL,
    video_id INT NOT NULL,
    watched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_completed TINYINT(1) DEFAULT 0,
    UNIQUE KEY idx_intern_video (intern_id, video_id),
    FOREIGN KEY (intern_id) REFERENCES interns(id) ON DELETE CASCADE,
    FOREIGN KEY (video_id) REFERENCES internship_videos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Intern Quiz Attempts Table
CREATE TABLE IF NOT EXISTS intern_quiz_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    intern_id INT NOT NULL,
    quiz_id INT NOT NULL,
    score INT NOT NULL, -- Percentage
    is_passed TINYINT(1) NOT NULL,
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (intern_id) REFERENCES interns(id) ON DELETE CASCADE,
    FOREIGN KEY (quiz_id) REFERENCES internship_quizzes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- View Progress Track for certificate generation eligibility
CREATE OR REPLACE VIEW view_internship_progress AS
SELECT 
    e.intern_id,
    e.internship_id,
    COUNT(DISTINCT v.id) as total_videos,
    COUNT(DISTINCT vp.video_id) as watched_videos,
    COUNT(DISTINCT qa.quiz_id) as quizzes_passed
FROM internship_enrollments e
JOIN internship_videos v ON e.internship_id = v.internship_id
LEFT JOIN intern_video_progress vp ON e.intern_id = vp.intern_id AND v.id = vp.video_id AND vp.is_completed = 1
LEFT JOIN internship_quizzes q ON v.id = q.video_id
LEFT JOIN intern_quiz_attempts qa ON e.intern_id = qa.intern_id AND q.id = qa.quiz_id AND qa.is_passed = 1
WHERE e.enrollment_status = 'active'
GROUP BY e.intern_id, e.internship_id;
