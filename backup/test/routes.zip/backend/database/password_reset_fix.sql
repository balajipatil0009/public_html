-- Password Reset Table Fix
-- Run this script if the password_reset_requests table exists but is missing columns.
-- This will add the missing columns needed for the admin panel.

-- Add created_at column if missing
ALTER TABLE password_reset_requests 
ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- Add updated_at column if missing
ALTER TABLE password_reset_requests 
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Add approved_at column if missing
ALTER TABLE password_reset_requests 
ADD COLUMN IF NOT EXISTS approved_at DATETIME NULL;

-- Add used_at column if missing
ALTER TABLE password_reset_requests 
ADD COLUMN IF NOT EXISTS used_at DATETIME NULL;

-- Add admin_notes column if missing
ALTER TABLE password_reset_requests 
ADD COLUMN IF NOT EXISTS admin_notes TEXT NULL;

-- Add indexes if not already present (errors are OK if already exist)
-- CREATE INDEX IF NOT EXISTS idx_status ON password_reset_requests(status);
-- CREATE INDEX IF NOT EXISTS idx_email ON password_reset_requests(email);
