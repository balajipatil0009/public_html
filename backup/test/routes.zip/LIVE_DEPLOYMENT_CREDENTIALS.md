# Live Deployment Credentials Guide

## Critical Files to Update for Live Hosting

When deploying to Wasmer or any live hosting service, you need to update the following configuration files with your production credentials.

---

## 1. Database Configuration
**File:** `backend/config/database.php`

```php
private $host = 'localhost';           // Change to your hosting DB host
private $db_name = 'itinfo_academy';   // Change to your live database name
private $username = 'root';            // Change to your live DB username
private $password = '';                // Change to your live DB password
```

**What to change:**
- `$host`: Your hosting provider's MySQL host (e.g., `mysql.yourhost.com` or keep `localhost`)
- `$db_name`: Your production database name (may be different from local)
- `$username`: Your production database username (NOT root in production)
- `$password`: Your production database password (MUST be strong)

---

## 2. Site Configuration
**File:** `backend/config/config.php`

```php
define('SITE_URL', 'http://localhost');
define('ADMIN_URL', SITE_URL . '/backend/admin');
```

**What to change:**
- `SITE_URL`: Change to your live domain (e.g., `https://itinfoacademy.com`)
- Make sure to use `https://` for security

**Example:**
```php
define('SITE_URL', 'https://itinfoacademy.com');
define('ADMIN_URL', SITE_URL . '/backend/admin');
```

---

## 3. AI Chatbot API Key
**File:** `backend/config/config.php`

```php
define('GROQ_API_KEY', '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');
```

**What to change:**
- If you want to use your own GROQ API key, replace this
- Get a free key from: https://console.groq.com/
- Current key is exposed in code, consider rotating it for security

---

## 4. Payment Gateway (Razorpay)
**File:** `backend/config/payment_config.php`

```php
return [
    'key_id' => 'rzp_live_S1lrUos81LWTsX',
    'key_secret' => 'FPrKMl0yYk4dQQmBqopGatvS'
];
```

**CRITICAL - What to change:**
- `key_id`: Your Razorpay LIVE Key ID (starts with `rzp_live_`)
- `key_secret`: Your Razorpay LIVE Key Secret

**Important Notes:**
- These are LIVE credentials - keep them secure
- Never commit these to public repositories
- Get your credentials from: https://dashboard.razorpay.com/app/keys
- Test mode keys start with `rzp_test_`, live keys start with `rzp_live_`

---

## 5. Admin Credentials
**Database Table:** `admin_users`

**Default credentials:**
- Username: `admin`
- Password: `admin123`

**CRITICAL - What to change:**
After deployment, immediately change the admin password:

1. Login to admin panel: `https://yourdomain.com/backend/admin/login.php`
2. Go to admin user management (if available) OR
3. Run this SQL query in your live database:

```sql
UPDATE admin_users 
SET password = '$2y$10$YOUR_NEW_HASHED_PASSWORD_HERE'
WHERE username = 'admin';
```

To generate a new password hash, use this PHP code:
```php
<?php
echo password_hash('your_new_strong_password', PASSWORD_BCRYPT);
?>
```

---

## 6. Error Reporting (Security)
**File:** `backend/config/config.php`

```php
error_reporting(E_ALL);
ini_set('display_errors', 0);  // Already set to 0 - GOOD!
```

**What to verify:**
- `display_errors` should be `0` in production (already correct)
- This prevents exposing sensitive error information to users

---

## 7. File Upload Directory
**File:** `backend/config/config.php`

```php
define('UPLOAD_DIR', '../uploads/');
```

**What to verify:**
- Ensure the `uploads/` directory exists on your live server
- Set proper permissions (755 for directory, 644 for files)
- Ensure web server can write to this directory

---

## 8. Session Security
**File:** `backend/config/config.php`

```php
define('SESSION_TIMEOUT', 3600); // 1 hour
```

**Optional changes:**
- Adjust session timeout if needed (currently 1 hour)
- Consider adding session security settings in production

---

## Quick Deployment Checklist

- [ ] Update database credentials in `backend/config/database.php`
- [ ] Update SITE_URL to your live domain in `backend/config/config.php`
- [ ] Update Razorpay credentials in `backend/config/payment_config.php`
- [ ] Change admin password after first login
- [ ] Verify error reporting is disabled (`display_errors = 0`)
- [ ] Test database connection
- [ ] Test payment gateway with test transaction
- [ ] Verify file upload permissions
- [ ] Test admin login
- [ ] Test intern registration and login
- [ ] Test video progress tracking
- [ ] Test application submission

---

## Security Best Practices

1. **Never use default credentials in production**
2. **Use HTTPS** - Ensure SSL certificate is installed
3. **Strong passwords** - Use complex passwords for database and admin
4. **File permissions** - Set proper permissions (755 for directories, 644 for files)
5. **Backup regularly** - Set up automated database backups
6. **Keep credentials secret** - Never commit sensitive data to version control
7. **Update regularly** - Keep PHP and MySQL updated
8. **Monitor logs** - Check error logs regularly for issues

---

## Environment-Specific Files Summary

| File | What to Change | Priority |
|------|---------------|----------|
| `backend/config/database.php` | DB host, name, username, password | CRITICAL |
| `backend/config/config.php` | SITE_URL, ADMIN_URL | CRITICAL |
| `backend/config/payment_config.php` | Razorpay key_id, key_secret | CRITICAL |
| Admin password in database | Change default admin123 | CRITICAL |
| `backend/config/config.php` | GROQ_API_KEY (optional) | MEDIUM |

---

## Testing After Deployment

1. Visit your live site: `https://yourdomain.com`
2. Test intern registration: `https://yourdomain.com/apply.php`
3. Test admin login: `https://yourdomain.com/backend/admin/login.php`
4. Test payment flow with a small test transaction
5. Test video player and progress tracking
6. Check all forms and submissions

---

## Support

If you encounter issues after deployment:
1. Check PHP error logs on your hosting server
2. Verify database connection
3. Test each configuration file individually
4. Ensure all required PHP extensions are installed (PDO, MySQL, JSON)

---

**Last Updated:** January 17, 2026
